package com.edubridge.service;


import com.edubridge.model.UserAnswer;

public interface UserAnswerService {

		public UserAnswer saveUserAnswer(UserAnswer userAnswer);

}
